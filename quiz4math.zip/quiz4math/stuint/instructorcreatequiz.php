<?php
// Start session
session_start();
if (!isset($_SESSION['instructor_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = 'login.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to generate a unique question ID
function generateUniqueQuestionId($conn) {
    while (true) {
        $randomId = 'ques_' . rand(10000, 99999); // Generate a random 5-digit number
        $checkQuery = "SELECT question_id FROM question WHERE question_id = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param('s', $randomId);
        $checkStmt->execute();
        $checkStmt->store_result();
        if ($checkStmt->num_rows === 0) { // If no rows returned, ID is unique
            $checkStmt->close();
            return $randomId;
        }
        $checkStmt->close();
    }
}

// Handle form submission to save all questions
$success_message = ""; // Initialize success message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quiz_id']) && isset($_POST['questions'])) {
    $quiz_id = $_POST['quiz_id'];
    $questions = $_POST['questions']; // Questions and their details
    $instructor_id = $_SESSION['instructor_id'];

    $conn->begin_transaction(); // Start transaction

    try {
        foreach ($questions as $index => $question_data) {
            $question_id = generateUniqueQuestionId($conn); // Generate unique ID

            $sql = "REPLACE INTO question (question_id, quiz_id, question, option_a, option_b, option_c, option_d, correct_answer)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        'ssssssss',
        $question_id,
        $quiz_id,
        $question_data['question'],
        $question_data['options'][0],
        $question_data['options'][1],
        $question_data['options'][2],
        $question_data['options'][3],
        $question_data['correct_answer'] // Use the correct_answer field directly
    );
    
    


            $stmt->execute();
            $stmt->close();
        }

        // Add 100 credits to the instructor's balance
        $updateBalanceQuery = "UPDATE instructor SET balance = balance + 100 WHERE instructor_id = ?";
        $balanceStmt = $conn->prepare($updateBalanceQuery);
        $balanceStmt->bind_param('s', $instructor_id);
        $balanceStmt->execute();
        $balanceStmt->close();

        $conn->commit(); // Commit transaction
        $conn->commit(); // Commit transaction
        header("Location: instructorquiz.php");
        exit();

    } catch (Exception $e) {
        $conn->rollback(); // Rollback transaction on failure
        $success_message = "Error saving quiz: " . $e->getMessage();
    }
}

// Get quiz_id from URL
if (!isset($_GET['quiz_id'])) {
    echo "<script>alert('No quiz selected.'); window.location.href = 'instructorprofile.php';</script>";
    exit;
}

$quiz_id = $_GET['quiz_id']; // Quiz ID from URL
$instructor_id = $_SESSION['instructor_id']; // Instructor ID from session

// Dynamic Theme Colors
$theme = "#f0f0f0"; // Default theme (light gray)
$buttonColor = "#007BFF"; // Default button color
$themeColors = [
    'item_1' => '#add8e6',  // Frost (light blue)
    'item_2' => '#7cfc00',  // Grass green
    'item_3' => '#2e1a47',  // Midnight (dark purple)
];
$buttonColors = [
    'item_1' => '#007bff',  // Frost theme button color (blue)
    'item_2' => '#32cd32',  // Grass theme button color (green)
    'item_3' => '#8a2be2',  // Midnight theme button color (purple)
];

// Fetch equipped theme for the instructor
$themeQuery = "SELECT u.item_id FROM useritem u WHERE u.instructor_id = ? AND u.is_equipped = 1 LIMIT 1";
$themeStmt = $conn->prepare($themeQuery);
$themeStmt->bind_param('s', $instructor_id);
$themeStmt->execute();
$result = $themeStmt->get_result();

if ($result && $result->num_rows > 0) {
    $equippedItem = $result->fetch_assoc()['item_id'];
    if (array_key_exists($equippedItem, $themeColors)) {
        $theme = $themeColors[$equippedItem];
        $buttonColor = $buttonColors[$equippedItem];
    }
}
$themeStmt->close();

// Fetch quiz details
$sql = "SELECT title, question FROM quiz WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $quiz_id);
$stmt->execute();
$result = $stmt->get_result();
$quiz = $result->fetch_assoc();

if (!$quiz) {
    echo "<script>alert('Quiz not found.'); window.location.href = 'instructorprofile.php';</script>";
    exit;
}

$title = $quiz['title'];
$max_questions = $quiz['question']; // Max questions allowed for this quiz
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz - <?php echo htmlspecialchars($title); ?></title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: <?php echo $theme; ?>;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        .question-block {
            margin-bottom: 20px;
        }
        textarea, input, select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .submit-btn {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        .submit-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Quiz: <?php echo htmlspecialchars($title); ?></h1>
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form id="quizForm" method="POST">
            <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
            <?php for ($i = 0; $i < $max_questions; $i++): ?>
                <div class="question-block">
                    <label for="question-<?php echo $i; ?>">Question <?php echo $i + 1; ?>:</label>
                    <textarea name="questions[<?php echo $i; ?>][question]" id="question-<?php echo $i; ?>" rows="3"></textarea>
                    <label>Options:</label>
                    <input type="text" name="questions[<?php echo $i; ?>][options][]" placeholder="Option A" 
                           oninput="updateDropdownOptions(<?php echo $i; ?>)">
                    <input type="text" name="questions[<?php echo $i; ?>][options][]" placeholder="Option B" 
                           oninput="updateDropdownOptions(<?php echo $i; ?>)">
                    <input type="text" name="questions[<?php echo $i; ?>][options][]" placeholder="Option C" 
                           oninput="updateDropdownOptions(<?php echo $i; ?>)">
                    <input type="text" name="questions[<?php echo $i; ?>][options][]" placeholder="Option D" 
                           oninput="updateDropdownOptions(<?php echo $i; ?>)">
                    <label>Correct Answer:</label>
                    <select name="questions[<?php echo $i; ?>][correct_answer]" id="correct-answer-<?php echo $i; ?>">
                        <option value="">Select the correct answer</option>
                    </select>
                </div>
            <?php endfor; ?>
            <button type="submit" class="submit-btn">Submit Quiz</button>
        </form>
    </div>

    <!-- JavaScript -->
    <script>
        function updateDropdownOptions(questionIndex) {
            const selectElement = document.getElementById(`correct-answer-${questionIndex}`);
            const optionInputs = document.querySelectorAll(`input[name="questions[${questionIndex}][options][]"]`);
            
            // Clear the dropdown options
            selectElement.innerHTML = '<option value="">Select the correct answer</option>';
            
            // Add the values from the input fields to the dropdown
            optionInputs.forEach((input, index) => {
                if (input.value.trim() !== "") { // Only add non-empty inputs
                    const option = document.createElement('option');
                    option.value = input.value.trim();
                    option.textContent = input.value.trim();
                    selectElement.appendChild(option);
                }
            });
        }
    </script>
</body>
</html>
