<?php
// Start session
session_start();
if (!isset($_SESSION['instructor_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = 'login.php';</script>";
    exit;
}

// Fetch instructor details
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check for equipped item and fetch its theme
$equippedTheme = "#808080"; // Default theme (gray)
$themeColors = [
    'item_1' => '#add8e6',  // Frost (light blue)
    'item_2' => '#7cfc00',  // grass
    'item_3' => '#2e1a47', // midnight
];

$instructor_id = $_SESSION['instructor_id']; // First, assign the instructor ID

$themeQuery = "
    SELECT u.item_id 
    FROM useritem u 
    WHERE u.instructor_id = '$instructor_id' AND u.is_equipped = 1
    LIMIT 1";
$result = $conn->query($themeQuery);
if ($result->num_rows > 0) {
    $equippedItem = $result->fetch_assoc()['item_id'];
    if (array_key_exists($equippedItem, $themeColors)) {
        $equippedTheme = $themeColors[$equippedItem];
    }
}

$instructor_id = $_SESSION['instructor_id'];
$sql = "SELECT name, balance FROM instructor WHERE instructor_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $instructor_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
$conn->close();

$name = $user['name'];
$balance = $user['balance'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .profile-container {
            background-color: <?php echo $equippedTheme; ?>; /* Theme color */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            width: 600px;
            color: #000;
        }

        .header {
            text-align: center;
            padding: 20px;
        }

        .header img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            display: block;
        }

        .header h2 {
            margin: 10px 0;
            font-size: 24px;
            font-weight: bold;
            color: #000;
            text-shadow: 1px 1px 4px rgba(255, 255, 255, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .header h2 .profile-pic {
            margin-left: 10px;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: <?php echo $equippedTheme; ?>;
            background-color: #add8e6;
            padding: 5px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .header h2 .profile-pic img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .content {
            padding: 20px;
        }

        .content h2 {
            margin: 5px 0;
            font-size: 18px;
            font-weight: normal;
        }

        .stats {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .btn-container {
            text-align: center;
            margin-top: 20px;
        }

        .btn-container a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            width: fit-content;
        }

        .btn-container a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <div class="header">
            <img src="image/logo.jpg" alt="Header Image">
            <h2>
                <?php echo htmlspecialchars($name); ?>
                <div class="profile-pic">
                    <img src="image/male.jpg" alt="Profile Icon">
                </div>
            </h2>
        </div>
        <div class="content">
            <h2>Profile Details</h2>
            <div class="stats">
                Balance: $<?php echo htmlspecialchars($balance); ?>
            </div>
        </div>
        <div class="btn-container">
            <a href="instructorquiz.php" class="quiz-btn">View Quizzes</a>
            <a href="instructorshop.php" class="shop-btn">Visit Shop</a>
            <a href="login.php" class="logout-btn">Logout</a>
            <a href="instructorchangetheme.php" class="theme-btn">Change Theme</a>
        </div>
    </div>
</body>
</html>
