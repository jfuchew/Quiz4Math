<?php
session_start(); // Start session management

// Check if the user is logged in as an instructor
if (!isset($_SESSION['instructor_id'])) {
    header("Location: login.php"); // Redirect to login page
    exit();
}

$instructor_id = $_SESSION['instructor_id']; // Move this here

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "quiz4math";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Theme and Button Colors
$theme = "#f0f0f0"; // Default theme
$buttonColor = "#007BFF";
$themeColors = [
    'item_1' => '#add8e6',  // Frost
    'item_2' => '#7cfc00',  // Grass
    'item_3' => '#2e1a47',  // Midnight
];
$buttonColors = [
    'item_1' => '#007bff',  // Frost button
    'item_2' => '#32cd32',  // Grass button
    'item_3' => '#8a2be2',  // Midnight button
];

// Fetch equipped theme for the instructor
$themeQuery = "SELECT u.item_id FROM useritem u WHERE u.instructor_id = ? AND u.is_equipped = 1 LIMIT 1";
$themeStmt = $conn->prepare($themeQuery);
$themeStmt->bind_param('s', $instructor_id);
$themeStmt->execute();
$result = $themeStmt->get_result();

if ($result && $result->num_rows > 0) {
    $equippedItem = $result->fetch_assoc()['item_id'];
    if (isset($equippedItem) && array_key_exists($equippedItem, $themeColors)) {
        $theme = $themeColors[$equippedItem];
        $buttonColor = $buttonColors[$equippedItem];
    }
}
$themeStmt->close();

// Fetch instructor balance
$balanceQuery = "SELECT balance FROM instructor WHERE instructor_id = ?";
$stmt = $conn->prepare($balanceQuery);
$stmt->bind_param('s', $instructor_id);
$stmt->execute();
$balanceResult = $stmt->get_result();
$balance = $balanceResult->fetch_assoc()['balance'];

// Fetch shop items
$sql = "SELECT * FROM shop WHERE display = 1";
$result = $conn->query($sql);

// Handle purchases
if (isset($_POST['submit_purchase'])) {
    $theme_id = $_POST['theme_id'];
    $price = $_POST['price'];

    if ($balance >= $price) {
        $new_balance = $balance - $price;
        $conn->query("UPDATE instructor SET balance = '$new_balance' WHERE instructor_id = '$instructor_id'");

        $userItemId = "UI_" . uniqid();
        $conn->query("INSERT INTO useritem (useritem_id, instructor_id, item_id, is_equipped) 
                      VALUES ('$userItemId', '$instructor_id', '$theme_id', 0)");
        echo '<script>alert("Purchase successful!"); window.location.href = "instructorshop.php";</script>';
    } else {
        echo '<script>alert("Insufficient balance!");</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Themes</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: <?php echo $theme; ?>;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px;
    }
    .header {
        text-align: center;
        background-color: #d9d9d9;
        padding: 20px 0;
    }
    .header h1 {
        margin: 0;
        font-size: 24px;
    }
    .themes {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 10px;
        margin-top: 20px;
    }
    .theme-item {
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        text-align: center;
        padding: 10px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .theme-item:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    }
    .theme-item h3 {
        font-size: 14px;
        margin: 5px 0;
    }
    .theme-item p {
        font-size: 12px;
        color: #666;
        margin: 5px 0 10px;
    }
    .theme-item .price {
        font-size: 14px;
        font-weight: bold;
        margin: 5px 0;
    }
    .theme-item button {
        background: #000;
        color: #fff;
        padding: 8px 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 12px;
    }
    .theme-item button:hover {
        background: #444;
    }
    .back-button {
        display: inline-block;
        margin: 10px 0;
        padding: 8px 16px;
        background: #ff5733;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        transition: background 0.3s ease;
    }
    .back-button:hover {
        background: #ff2d00;
    }

    @media (max-width: 480px) {
        .themes {
            gap: 5px;
        }
        .theme-item {
            padding: 8px;
        }
        .theme-item h3 {
            font-size: 12px;
        }
        .theme-item p, .theme-item .price {
            font-size: 10px;
        }
        .theme-item button {
            font-size: 10px;
            padding: 6px 8px;
        }
    }
</style>

</head>
<body>

<div class="container">
    <div class="header">
        <h1>Themes</h1>
        <!-- Back Button -->
        <a href="instructorquiz.php" class="back-button">Back</a>
    </div>
    
    <div class="container">
        <div class="themes">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="theme-item">
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><?php echo htmlspecialchars($row['description']); ?></p>
                    <p>Price: $<?php echo htmlspecialchars($row['price']); ?></p>
                    <form method="POST">
                        <input type="hidden" name="theme_id" value="<?php echo $row['item_id']; ?>">
                        <input type="hidden" name="price" value="<?php echo $row['price']; ?>">
                        <button type="submit" name="submit_purchase">Buy Now</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>
