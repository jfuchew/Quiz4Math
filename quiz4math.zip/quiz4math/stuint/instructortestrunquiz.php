<?php
session_start();
if (!isset($_SESSION['instructor_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = 'login.php';</script>";
    exit;
}

$instructor_id = $_SESSION['instructor_id'];
$quiz_id = isset($_GET['quiz_id']) ? $_GET['quiz_id'] : null;

if (!$quiz_id) {
    echo "<script>alert('Quiz ID is required.'); window.location.href = 'test_run_page.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Dynamic Theme Colors
$theme = "#ffffff"; // Default theme (white)
$buttonColor = "#000"; // Default button color (black)
$themeColors = [
    'item_1' => '#add8e6',  // Frost (light blue)
    'item_2' => '#7cfc00',  // Grass green
    'item_3' => '#2e1a47',  // Midnight (dark purple)
];
$buttonColors = [
    'item_1' => '#007bff',  // Frost theme button color (blue)
    'item_2' => '#32cd32',  // Grass theme button color (green)
    'item_3' => '#8a2be2',  // Midnight theme button color (purple)
];

// Fetch equipped theme for the instructor
$themeQuery = "SELECT u.item_id FROM useritem u WHERE u.instructor_id = ? AND u.is_equipped = 1 LIMIT 1";
$stmt = $conn->prepare($themeQuery);
$stmt->bind_param("s", $instructor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $equippedItem = $result->fetch_assoc()['item_id'];
    if (array_key_exists($equippedItem, $themeColors)) {
        $theme = $themeColors[$equippedItem];
        $buttonColor = $buttonColors[$equippedItem];
    }
}

// Fetch questions for the quiz
$sql = "SELECT question_id, question, option_a, option_b, option_c, option_d, correct_answer FROM question WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $quiz_id);
$stmt->execute();
$questions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($questions)) {
    echo "<script>alert('No questions available for this quiz.'); window.location.href = 'test_run_page.php';</script>";
    exit;
}

// Generate a unique test_id
$sql = "SELECT COUNT(*) AS count FROM testattempt";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$test_id = 'test_' . ($row['count'] + 1); // Updated format for test_id

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: <?php echo $theme; ?>;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            width: 100%;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            font-size: 24px;
            color: #444;
            margin-bottom: 10px;
        }

        #clock {
            text-align: center;
            font-size: 18px;
            color: #666;
            margin-bottom: 20px;
        }

        .question {
            margin-bottom: 20px;
        }

        .question p {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .options label {
            display: block;
            margin-bottom: 8px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.2s, border-color 0.2s;
        }

        .options input[type="radio"] {
            display: none;
        }

        .options input[type="radio"]:checked + label {
            background-color: #f0f0f0;
            border-color: #bbb;
        }

        button {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: #444;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #333;
        }
    </style>
    <script>
        let startTime;

        function startClock() {
            startTime = new Date();
            setInterval(() => {
                const now = new Date();
                const elapsed = Math.floor((now - startTime) / 1000);
                const minutes = Math.floor(elapsed / 60);
                const seconds = elapsed % 60;
                document.getElementById('clock').textContent = `${minutes}:${seconds < 10 ? '0' + seconds : seconds}`;
            }, 1000);

            document.getElementById('start_time').value = startTime.toISOString();
        }

        function endQuiz() {
            const endTime = new Date();
            document.getElementById('end_time').value = endTime.toISOString();
        }
    </script>
</head>
<body onload="startClock()">
    <div class="container">
        <h1>Quiz</h1>
        <div id="clock">0:00</div>
        <form id="quiz-form" action="submittestquiz.php" method="POST" onsubmit="endQuiz()">
            <input type="hidden" name="test_id" value="<?php echo $test_id; ?>">
            <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
            <input type="hidden" name="instructor_id" value="<?php echo $instructor_id; ?>">
            <input type="hidden" id="start_time" name="start_time">
            <input type="hidden" id="end_time" name="end_time">

            <?php foreach ($questions as $index => $question): ?>
    <div class="question">
        <p><?php echo ($index + 1) . '. ' . htmlspecialchars($question['question']); ?></p>
        <div class="options">
            <input type="radio" id="q<?php echo $index; ?>a" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_a']); ?>" required>
            <label for="q<?php echo $index; ?>a"><strong>A.</strong> <?php echo htmlspecialchars($question['option_a']); ?></label>

            <input type="radio" id="q<?php echo $index; ?>b" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_b']); ?>">
            <label for="q<?php echo $index; ?>b"><strong>B.</strong> <?php echo htmlspecialchars($question['option_b']); ?></label>

            <input type="radio" id="q<?php echo $index; ?>c" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_c']); ?>">
            <label for="q<?php echo $index; ?>c"><strong>C.</strong> <?php echo htmlspecialchars($question['option_c']); ?></label>

            <input type="radio" id="q<?php echo $index; ?>d" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_d']); ?>">
            <label for="q<?php echo $index; ?>d"><strong>D.</strong> <?php echo htmlspecialchars($question['option_d']); ?></label>
        </div>
    </div>
<?php endforeach; ?>
            <button type="submit">Submit Quiz</button>
        </form>
    </div>
</body>
</html>

