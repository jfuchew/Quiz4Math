<?php
$con = mysqli_connect("localhost","root","","quiz4math");

if (mysqli_connect_error()) {
    echo "Failed to conenct to MySQL: ".mysqli_connect_error();
}
?>