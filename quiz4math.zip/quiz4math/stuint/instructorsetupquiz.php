<?php
// Start session
session_start();

// Check if instructor is logged in
if (!isset($_SESSION['instructor_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = 'login.php';</script>";
    exit;
}

// Retrieve instructor_id from the session
$instructor_id = $_SESSION['instructor_id'];

// Debugging: Ensure instructor_id is properly set
if (empty($instructor_id)) {
    error_log("Instructor ID is not set or is empty in the session.");
    die("Error: Instructor ID is missing. Please log in again.");
}

// Database connection
$conn = new mysqli("localhost", "root", "", "quiz4math");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Dynamic Theme Colors
$theme = "#ffffff"; // Default theme (white)
$buttonColor = "#000"; // Default button color (black)
$themeColors = [
    'item_1' => '#add8e6',  // Frost (light blue)
    'item_2' => '#7cfc00',  // Grass green
    'item_3' => '#2e1a47',  // Midnight (dark purple)
];
$buttonColors = [
    'item_1' => '#007bff',  // Frost theme button color (blue)
    'item_2' => '#32cd32',  // Grass theme button color (green)
    'item_3' => '#8a2be2',  // Midnight theme button color (purple)
];

// Fetch equipped theme for the instructor
$themeQuery = "SELECT u.item_id FROM useritem u WHERE u.instructor_id = ? AND u.is_equipped = 1 LIMIT 1";
$stmt = $conn->prepare($themeQuery);
$stmt->bind_param("s", $instructor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $equippedItem = $result->fetch_assoc()['item_id'];
    if (array_key_exists($equippedItem, $themeColors)) {
        $theme = $themeColors[$equippedItem];
        $buttonColor = $buttonColors[$equippedItem];
    }
}
$stmt->close();

// Flag to check if quiz was successfully created
$quizCreated = false;

// Quiz creation process
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $currency = intval($_POST['currency'] ?? 0);
    $question = intval($_POST['question'] ?? 0);

    if ($title && $category && isset($currency) && isset($question)) {
        // Generate unique quiz_id
        function generateUniqueQuizId($conn) {
            while (true) {
                $randomId = 'ques_' . rand(10000, 99999); // Generate a random 5-digit number
                $checkQuery = "SELECT quiz_id FROM quiz WHERE quiz_id = ?";
                $checkStmt = $conn->prepare($checkQuery);
                $checkStmt->bind_param('s', $randomId);
                $checkStmt->execute();
                $checkStmt->store_result();
                if ($checkStmt->num_rows === 0) { // If no rows returned, ID is unique
                    $checkStmt->close();
                    return $randomId;
                }
                $checkStmt->close();
            }
        }

        $quiz_id = generateUniqueQuizId($conn);

        // Check if instructor exists in the database
        $checkInstructorQuery = "SELECT COUNT(*) AS count FROM instructor WHERE instructor_id = ?";
        $checkStmt = $conn->prepare($checkInstructorQuery);
        $checkStmt->bind_param("s", $instructor_id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        $row = $checkResult->fetch_assoc();
        $checkStmt->close();

        if ($row['count'] > 0) {
            // Insert quiz into the database
            $sql = "INSERT INTO quiz (quiz_id, title, category, currency, question, instructor_id) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("sssiss", $quiz_id, $title, $category, $currency, $question, $instructor_id);
                if ($stmt->execute()) {
                    $quizCreated = true;
                } else {
                    error_log("Quiz insertion failed: " . $stmt->error);
                }
                $stmt->close();
            }
        } else {
            error_log("Instructor ID $instructor_id not found in the database.");
        }
    } else {
        error_log("Invalid input data for quiz creation.");
    }
}

$conn->close();

if ($quizCreated) {
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Success</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: ' . $theme . ';
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .message {
                font-size: 24px;
                color: #000;
            }
        </style>
        <script>
            setTimeout(() => { window.location.href = "instructorquiz.php"; }, 3000);
        </script>
    </head>
    <body>
        <div class="message">Quiz has been successfully created!</div>
    </body>
    </html>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Setup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: <?php echo $theme; ?>;
            color: #000;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .nav {
            background-color: #444;
            color: #fff;
            width: 100%;
            padding: 10px 20px;
            position: absolute;
            top: 0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            box-sizing: border-box;
        }
        .nav a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
        }
        .container {
            margin-top: 70px;
            text-align: center;
            padding: 10px;
            box-sizing: border-box;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .options {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }
        .options div {
            background-color: #fff;
            padding: 15px;
            border-radius: 8px;
            width: 100%;
            max-width: 180px;
            text-align: left;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }
        input[type="text"] {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            margin-top: 20px;
            padding: 10px 30px;
            font-size: 16px;
            color: #fff;
            background-color: <?php echo $buttonColor; ?>;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #333;
        }
        @media (max-width: 768px) {
            .nav {
                padding: 10px;
                font-size: 14px;
                gap: 5px;
            }
            h1 {
                font-size: 20px;
            }
            .options {
                flex-direction: column;
                gap: 10px;
            }
            .options div {
                max-width: 100%;
            }
        }
        @media (max-width: 480px) {
            h1 {
                font-size: 18px;
            }
            input[type="text"] {
                width: 100%;
            }
            button {
                padding: 10px 20px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="nav">
        <a href="instructorquiz.php">BACK</a>
        <a href="shop.php">SHOP</a>
    </div>
    <div class="container">
        <h1>Setup Quiz</h1>
        <form method="POST" action="">
            <label for="title">Quiz Title:</label><br>
            <input type="text" id="title" name="title" placeholder="Enter quiz title" required><br>
            <div class="options">
                <div>
                    <h3>Category</h3>
                    <label><input type="radio" name="category" value="Multiply" required> Multiply</label><br>
                    <label><input type="radio" name="category" value="Division" required> Division</label><br>
                    <label><input type="radio" name="category" value="Linear" required> Linear</label><br>
                    <label><input type="radio" name="category" value="Quadratic" required> Quadratic</label><br>
                </div>
                <div>
                    <h3>Currency</h3>
                    <label><input type="radio" name="currency" value="90" required> 90</label><br>
                    <label><input type="radio" name="currency" value="50" required> 50</label><br>
                </div>
                <div>
                    <h3>Questions</h3>
                    <label><input type="radio" name="question" value="3" required> 3</label><br>
                    <label><input type="radio" name="question" value="5" required> 5</label><br>
                    <label><input type="radio" name="question" value="10" required> 10</label><br>
                </div>
            </div>
            <button type="submit">Create Quiz</button>
        </form>
    </div>
</body>
</html>
