<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Query for student count
$studentQuery = "SELECT COUNT(*) AS total_students FROM student";
$studentResult = $conn->query($studentQuery);
$studentCount = $studentResult->fetch_assoc()['total_students'] ?? 0;

// Query for instructor count
$instructorQuery = "SELECT COUNT(*) AS total_instructors FROM instructor";
$instructorResult = $conn->query($instructorQuery);
$instructorCount = $instructorResult->fetch_assoc()['total_instructors'] ?? 0;

// Pagination for admin table
$recordsPerPage = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $recordsPerPage;

// Query to fetch admin accounts with LIMIT
$adminQuery = "SELECT admin_id, name, password, email FROM admin LIMIT $recordsPerPage OFFSET $offset";
$adminResult = $conn->query($adminQuery);

// Query to count total admin records
$totalAdminQuery = "SELECT COUNT(*) AS total FROM admin";
$totalAdminResult = $conn->query($totalAdminQuery);
$totalAdmins = $totalAdminResult->fetch_assoc()['total'] ?? 0;

// Calculate total pages
$totalPages = ceil($totalAdmins / $recordsPerPage);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f9;
      margin: 0;
    }

    .dashboard-container {
      display: flex;
      flex-wrap: wrap;
    }

    .main-content {
      padding: 20px;
      background-color: #ecf0f1;
      width: 100%;
      min-height: 100vh;
    }

    .content-center {
      max-width: 1200px;
      margin: 0 auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 16px;
    }

    table th,
    table td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: left;
    }

    table thead tr {
      background-color: #34495e;
      color: #ffffff;
    }

    table tbody tr:nth-child(even) {
      background-color: #f4f4f9;
    }

    button {
      cursor: pointer;
      border-radius: 4px;
    }

    button.toggle-password {
      border: none;
      background: none;
      padding: 0;
      margin: 0;
      outline: none;
    }

    button.toggle-password img {
      width: 20px;
      height: 20px;
    }

    button.add-account {
      background-color: #2ecc71;
      color: white;
      border: none;
      padding: 10px 15px;
      margin-bottom: 10px;
    }

    button.add-account:hover {
      background-color: #27ae60;
    }

    button.delete-selected {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 10px 15px;
      margin-top: 10px;
    }

    button.delete-selected:hover {
      background-color: #c0392b;
    }

    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }

    .pagination a {
      color: #3498db;
      padding: 10px 15px;
      text-decoration: none;
      border: 1px solid #ddd;
      border-radius: 4px;
      margin: 0 5px;
    }

    .pagination a:hover {
      background-color: #f1f1f1;
    }

    .pagination a.disabled {
      color: #aaa;
      pointer-events: none;
      cursor: not-allowed;
    }

    canvas {
      width: 100%;
      max-width: 800px;
      margin: 20px auto;
      display: block;
    }

    button.edit-account {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 8px 15px;
      font-size: 14px;
    }

    button.edit-account:hover {
      background-color: #2980b9;
    }

    @media (max-width: 768px) {
      .content-center {
        padding: 10px;
      }

      table th,
      table td {
        padding: 10px;
        font-size: 14px;
      }

      table {
        font-size: 14px;
      }

      button {
        padding: 8px 10px;
        font-size: 14px;
      }

      .pagination a {
        padding: 8px 10px;
      }

      canvas {
        max-width: 100%;
      }
    }

    @media (max-width: 480px) {
      table {
        display: block;
        overflow-x: auto;
      }

      table th,
      table td {
        white-space: nowrap;
      }

      button {
        display: block;
        margin-bottom: 10px;
      }

      .pagination {
        flex-wrap: wrap;
        gap: 10px;
      }
    }
  </style>
</head>

<body>

  <div class="dashboard-container">
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
      <div class="content-center">

        <h1>Admin Dashboard</h1><br><br>

        <h2>Admin Accounts</h2>
        <p>Showing <?= $offset + 1; ?> to <?= min($offset + $recordsPerPage, $totalAdmins); ?> of <?= $totalAdmins; ?>
          admin accounts</p>

        <button class="add-account" onclick="window.location.href='createadmin.php'">Add Account</button>

        <form method="POST" action="delete_selected.php">
          <table>
            <thead>
              <tr>
                <th><input type="checkbox" id="selectAll" onclick="toggleSelectAll(this)"></th>
                <th>Admin ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if ($adminResult && $adminResult->num_rows > 0) {
                while ($row = $adminResult->fetch_assoc()) {
                  $maskedPassword = str_repeat('*', strlen($row['password']));
                  echo "<tr>";
                  echo "<td><input type='checkbox' name='selected_ids[]' value='" . htmlspecialchars($row['admin_id']) . "'></td>";
                  echo "<td>" . htmlspecialchars($row['admin_id']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                  echo "<td>
                            <span class='password' data-password='" . htmlspecialchars($row['password']) . "'>$maskedPassword</span>
                            <button type='button' class='toggle-password' onclick='togglePassword(this)'>
                              <img src='eye-closed.png' alt='Show Password' class='eye-icon'>
                            </button>
                          </td>";
                  echo "<td class='action-buttons'>
                            <button type='button' class='edit-account' onclick=\"window.location.href='editadmin.php?id=" . htmlspecialchars($row['admin_id']) . "'\">Edit</button>
                          </td>";

                  echo "</tr>";
                }
              } else {
                echo "<tr><td colspan='5'>No admin accounts found</td></tr>";
              }
              ?>
            </tbody>
          </table>

          <button type="submit" class="delete-selected">Delete Selected</button>
        </form>

        <div class="pagination">
          <a href="?page=<?= max(1, $page - 1) ?>" class="<?= $page <= 1 ? 'disabled' : '' ?>">Previous</a>
          <a href="?page=<?= min($totalPages, $page + 1) ?>"
            class="<?= $page >= $totalPages ? 'disabled' : '' ?>">Next</a>
        </div>

        <h2>Current Users</h2>
        <canvas id="accountsChart"></canvas>

      </div>
    </div>
  </div>

  <script>
    function togglePassword(button) {
      const passwordSpan = button.previousElementSibling;
      const isMasked = passwordSpan.textContent.includes('*');
      const actualPassword = passwordSpan.getAttribute('data-password');
      const img = button.querySelector('.eye-icon');

      if (isMasked) {
        passwordSpan.textContent = actualPassword;
        img.src = 'assets/eye-open.png';
      } else {
        passwordSpan.textContent = '*'.repeat(actualPassword.length);
        img.src = 'assets/eye-closed.png';
      }
    }

    const accountsData = {
      labels: ['Students', 'Instructors'],
      datasets: [
        {
          label: 'Accounts',
          data: [<?= $studentCount; ?>, <?= $instructorCount; ?>],
          backgroundColor: ['rgba(54, 162, 235, 0.7)', 'rgba(255, 99, 132, 0.7)']
        }
      ]
    };

    const chartOptions = {
      responsive: true,
      plugins: {
        legend: {
          display: true,
          position: 'top'
        }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      }
    };

    new Chart(document.getElementById('accountsChart'), {
      type: 'bar',
      data: accountsData,
      options: chartOptions
    });

    function toggleSelectAll(checkbox) {
      const checkboxes = document.querySelectorAll("input[type='checkbox'][name='selected_ids[]']");
      checkboxes.forEach(cb => cb.checked = checkbox.checked);
    }
  </script>

</body>

</html>
