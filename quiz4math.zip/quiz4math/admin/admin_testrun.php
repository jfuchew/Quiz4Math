<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

$admin_id = $_SESSION['admin_id'];
$quiz_id = isset($_GET['quiz_id']) ? $_GET['quiz_id'] : null;

if (!$quiz_id) {
    echo "<script>alert('Quiz ID is required.'); window.location.href = 'admin_quiz_browse.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch questions for the quiz
$sql = "SELECT question_id, question, option_a, option_b, option_c, option_d, correct_answer FROM question WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $quiz_id);
$stmt->execute();
$questions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($questions)) {
    echo "<script>alert('No questions available for this quiz.'); window.location.href = 'admin_quiz_browse.php';</script>";
    exit;
}

// Generate a unique test_id
$sql = "SELECT COUNT(*) AS count FROM testattempt";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$test_id = 'test_' . ($row['count'] + 1); // Updated format for test_id

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Run Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: black;
        }
        h1 {
            text-align: center;
        }
        #clock {
            font-size: 20px;
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }
        .question-container {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 20px;
            margin: 20px;
            border-radius: 10px;
        }
        .question-container p {
            font-size: 18px;
        }
        .question-container input[type="radio"] {
            margin: 10px 0;
        }
        button[type="submit"] {
            display: block;
            width: 100%;
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        let startTime;

        function startClock() {
            startTime = new Date();
            setInterval(() => {
                const now = new Date();
                const elapsed = Math.floor((now - startTime) / 1000);
                const minutes = Math.floor(elapsed / 60);
                const seconds = elapsed % 60;
                document.getElementById('clock').textContent = `${minutes}:${seconds < 10 ? '0' + seconds : seconds}`;
            }, 1000);

            document.getElementById('start_time').value = startTime.toISOString();
        }

        function endQuiz() {
            const endTime = new Date();
            document.getElementById('end_time').value = endTime.toISOString();
        }
    </script>
</head>
<body onload="startClock()">
    <h1>Test Run Quiz</h1>
    <div id="clock"></div>

    <form id="quiz-form" action="admin_submit_test.php" method="POST" onsubmit="endQuiz()">
        <input type="hidden" name="test_id" value="<?php echo $test_id; ?>">
        <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">
        <input type="hidden" name="admin_id" value="<?php echo $admin_id; ?>">
        <input type="hidden" id="start_time" name="start_time">
        <input type="hidden" id="end_time" name="end_time">

        <?php foreach ($questions as $index => $question): ?>
    <div class="question-container">
        <p><?php echo ($index + 1) . '. ' . htmlspecialchars($question['question']); ?></p>
        <input type="radio" id="q<?php echo $index; ?>a" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_a']); ?>" required>
        <label for="q<?php echo $index; ?>a"><?php echo htmlspecialchars($question['option_a']); ?></label><br>

        <input type="radio" id="q<?php echo $index; ?>b" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_b']); ?>">
        <label for="q<?php echo $index; ?>b"><?php echo htmlspecialchars($question['option_b']); ?></label><br>

        <input type="radio" id="q<?php echo $index; ?>c" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_c']); ?>">
        <label for="q<?php echo $index; ?>c"><?php echo htmlspecialchars($question['option_c']); ?></label><br>

        <input type="radio" id="q<?php echo $index; ?>d" name="answer[<?php echo htmlspecialchars($question['question_id']); ?>]" value="<?php echo htmlspecialchars($question['option_d']); ?>">
        <label for="q<?php echo $index; ?>d"><?php echo htmlspecialchars($question['option_d']); ?></label><br>
    </div>
<?php endforeach; ?>


        <button type="submit">Submit Quiz</button>
    </form>
</body>
</html>
