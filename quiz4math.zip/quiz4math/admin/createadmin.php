<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input fields
    if (empty($name) || empty($email) || empty($password)) {
        $message = "All fields are required.";
    } else {
        // Generate a unique admin_id in the format admin_1, admin_2, etc.
        $idQuery = "SELECT admin_id FROM admin ORDER BY admin_id DESC LIMIT 1";
        $idResult = $conn->query($idQuery);
        if ($idResult && $idResult->num_rows > 0) {
            $lastId = $idResult->fetch_assoc()['admin_id'];
            preg_match('/\d+$/', $lastId, $matches);
            $nextIdNumber = isset($matches[0]) ? intval($matches[0]) + 1 : 1;
        } else {
            $nextIdNumber = 1;
        }
        $newAdminId = "admin_" . $nextIdNumber;

        // Insert the new admin into the database (password is stored as plain text)
        $insertQuery = "INSERT INTO admin (admin_id, name, email, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ssss", $newAdminId, $name, $email, $password);

        if ($stmt->execute()) {
            $message = "Admin account created successfully. Admin ID: $newAdminId.";
        } else {
            $message = "Error: Unable to create account.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Admin</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      background-color: #f4f4f9;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .form-container {
      background-color: #ffffff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
    }

    .form-container h1 {
      margin-bottom: 20px;
      text-align: center;
      color: #34495e;
    }

    .form-container label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-container input[type="text"], 
    .form-container input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-container button {
      background-color: #2ecc71;
      color: white;
      border: none;
      padding: 10px 15px;
      width: 100%;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    .form-container button:hover {
      background-color: #27ae60;
    }

    .form-container .back-button {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 10px 15px;
      width: 100%;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
    }

    .form-container .back-button:hover {
      background-color: #2980b9;
    }

    .message {
      margin-top: 20px;
      text-align: center;
      font-size: 14px;
      color: #e74c3c;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h1>Create Admin Account</h1>
    <form method="POST" action="">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" placeholder="Enter name" required>

      <label for="email">Email:</label>
      <input type="text" id="email" name="email" placeholder="Enter email" required>

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" placeholder="Enter password" required>

      <button type="submit">Create Account</button>
    </form>

    <!-- Back Button -->
    <button class="back-button" onclick="window.location.href='adminhomepage.php'">Back to Admin Dashboard</button>

    <?php if (!empty($message)): ?>
      <p class="message"><?= htmlspecialchars($message); ?></p>
    <?php endif; ?>
  </div>
</body>
</html>
