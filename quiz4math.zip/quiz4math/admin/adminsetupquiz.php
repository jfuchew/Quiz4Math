<?php
// Start session to retrieve logged-in admin_id
session_start();
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

$admin_id = $_SESSION['admin_id']; // Get admin_id from session

// Debug session to ensure admin_id is set
if (!isset($_SESSION['admin_id'])) {
    var_dump($_SESSION);
    echo "<script>alert('Session admin_id is not set. Please log in again.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli("localhost", "root", "", "quiz4math");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the admin_id exists in the admin table
$checkAdminQuery = "SELECT COUNT(*) AS count FROM admin WHERE admin_id = ?";
$checkStmt = $conn->prepare($checkAdminQuery);
$checkStmt->bind_param("s", $admin_id);
$checkStmt->execute();
$result = $checkStmt->get_result();
$row = $result->fetch_assoc();
$checkStmt->close();

if ($row['count'] === 0) {
    echo "<script>alert('Invalid admin ID. Please log in again.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

$quizCreated = false;
$quiz_id = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string(trim($_POST['title'] ?? ''));
    $category = $conn->real_escape_string(trim($_POST['category'] ?? ''));
    $currency = intval($_POST['currency'] ?? 0);
    $question = intval($_POST['question'] ?? 0);

    if ($title && $category && isset($currency) && isset($question)) {
        function generateUniqueQuizId($conn)
        {
            while (true) {
                $quiz_id = 'Q_' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));
                $checkQuery = "SELECT quiz_id FROM quiz WHERE quiz_id = ?";
                $stmt = $conn->prepare($checkQuery);
                $stmt->bind_param("s", $quiz_id);
                $stmt->execute();
                $stmt->store_result();
                if ($stmt->num_rows === 0) {
                    $stmt->close();
                    return $quiz_id;
                }
                $stmt->close();
            }
        }

        $quiz_id = generateUniqueQuizId($conn);

        $sql = "INSERT INTO quiz (quiz_id, title, category, currency, question, admin_id) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("sssiss", $quiz_id, $title, $category, $currency, $question, $admin_id);
            if ($stmt->execute()) {
                $quizCreated = true;
            } else {
                echo "<script>alert('Database error: " . $stmt->error . "');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Error preparing the SQL statement.');</script>";
        }
    } else {
        echo "<script>alert('Please fill out all fields correctly.');</script>";
    }
}

$conn->close();

if ($quizCreated) {
    header("Location: admin_create_quiz.php?quiz_id=$quiz_id");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Setup</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('assets/login.png');
            color: #000;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            text-align: center;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 32px;
            margin-bottom: 20px;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .options div {
            margin-bottom: 20px;
        }

        button {
            padding: 12px 40px;
            font-size: 16px;
            color: #fff;
            background-color: #007BFF;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Setup Quiz</h1>
        <form method="POST" action="">
            <label for="title">Quiz Title:</label>
            <input type="text" id="title" name="title" placeholder="Enter quiz title here" required>

            <div class="options">
                <div>
                    <h3>Category</h3>
                    <label><input type="radio" name="category" value="Multiply" required> Multiply</label>
                    <label><input type="radio" name="category" value="Division" required> Division</label>
                    <label><input type="radio" name="category" value="Linear" required> Linear</label>
                    <label><input type="radio" name="category" value="Quadratic" required> Quadratic</label>
                </div>
                <div>
                    <h3>Currency Earn</h3>
                    <label><input type="radio" name="currency" value="90" required> 90</label>
                    <label><input type="radio" name="currency" value="50" required> 50</label>

                </div>
                <div>
                    <h3>Number of Questions</h3>
                    <label><input type="radio" name="question" value="3" required> 3</label>
                    <label><input type="radio" name="question" value="5" required> 5</label>
                    <label><input type="radio" name="question" value="10" required> 10</label>
                </div>
            </div>

            <button type="submit">Create Quiz</button>
            <div style="margin-top: 20px;">
                <a href="adminhomepage.php">
                    <button type="button" style="background-color: #ff9900; margin-top: 10px;">Back to
                        Dashboard</button>
                </a>
            </div>
        </form>
    </div>
</body>

</html>