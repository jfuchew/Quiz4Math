<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'selected_ids' is set and not empty
if (isset($_POST['selected_ids']) && !empty($_POST['selected_ids'])) {
    $studentIds = $_POST['selected_ids'];

    // Sanitize and prepare the student IDs
    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $deleteQuery = "DELETE FROM student WHERE student_id IN ($placeholders)";
    $stmt = $conn->prepare($deleteQuery);

    // Dynamically bind the parameters
    $types = str_repeat('s', count($studentIds)); // 's' for each student_id (all are strings)
    $stmt->bind_param($types, ...$studentIds);

    if ($stmt->execute()) {
        // Redirect back to studentmanagement with success message
        $count = count($studentIds);
        header("Location: studentmanagement.php?message=Successfully deleted $count student(s).");
        exit;
    } else {
        // Redirect back to studentmanagement with error message
        header("Location: studentmanagement.php?message=Error: Unable to delete selected students.");
        exit;
    }

    $stmt->close();
} else {
    // Redirect back to studentmanagement if no students are selected
    header("Location: studentmanagement.php?message=Error: No students selected for deletion.");
    exit;
}

$conn->close();
?>
