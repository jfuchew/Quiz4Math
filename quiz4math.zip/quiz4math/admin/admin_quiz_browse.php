<?php
session_start(); // Start session management

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../stuint/login.php"); // Redirect to admin login page if not logged in
    exit();
}

// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "quiz4math"; // Replace with your database name

// Connect to MySQL database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch quizzes from the database
$allQuizzes = [];
$allQuizzesQuery = "SELECT quiz_id, title, category FROM quiz";
$result = $conn->query($allQuizzesQuery);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $allQuizzes[] = $row;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Browse Quizzes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #34495e;
            color: white;
        }
        /* Align header-left content (logo and dropdown) */
        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
            /* Space between logo and filter button */
        }

        .header-left img {
            width: 50px;
            height: 50px;
        }

        .dropdown {
            position: relative;
        }

        .dropdown button {
            background-color: #000000;
            color: white;
            font-weight: bold;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .dropdown button:hover {
            background-color: #666;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #333;
            color: white;
            border-radius: 5px;
            padding: 10px;
            z-index: 1000;
        }

        .dropdown-menu a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: white;
        }

        .dropdown-menu a:hover {
            background-color: #666;
        }

        .header-right .back-btn {
            background-color: #ff9900;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        main {
            padding: 20px;
        }

        .quiz-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center;
        }

        .quiz-card {
            position: relative;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            width: 200px;
            height: 100px;
            text-align: center;
            cursor: pointer;
            overflow: hidden;
            transition: transform 0.4s ease-in-out, background-color 0.4s ease-in-out;
        }

        .quiz-card.fade-out {
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
        }

        .quiz-card:hover {
            transform: scale(1.05);
        }

        .quiz-card .main-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 1;
            transition: opacity 0.3s ease-in-out;
        }

        .quiz-card:hover .main-content {
            opacity: 0;
        }

        .quiz-card .parts {
            display: flex;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
        }

        .quiz-card:hover .parts {
            display: flex;
            opacity: 1;
        }

        .quiz-card .part {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            pointer-events: auto;
        }

        .part img {
            width: 30px;
            height: 30px;
        }

        .part.test-run {
            background-color: #28a745;
        }

        .part.edit {
            background-color: #ff9800;
        }

        .part.delete {
            background-color: #dc3545;
        }

        .part.test-run:hover {
            background-color: #218838;
        }

        .part.edit:hover {
            background-color: #e0a800;
        }

        .part.delete:hover {
            background-color: #c82333;
        }

        @media (max-width: 768px) {

            .dropdown button {
                padding: 8px 10px; 
                font-size: 12px; 
            }

            #search-bar {
                width: 150px !important; 
                padding: 8px !important;
                font-size: 12px !important;
                margin-left: 10px !important; 
            }
            .header-right .back-btn {
            width: 100%; 
            padding: 10px 0; 
            font-size: 14px; 
            text-align: center; 
            margin-top: 10px; 
            }

            .header-right {
            width: 100%;
            text-align: center;
            }
        
            .quiz-card {
                width: 180px;
                height: 90px;
            }

            #search-bar {
                width: 100%;
                margin-top: 10px;
            }
        }

        .part img {
            width: 20px;
            height: 20px;
        }


        #search-bar {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-left: 20px;
            width: 250px;
        }

        #search-bar:focus {
            outline: none;
            border-color: #007bff;
        }
    </style>
</head>

<body>

    <header>
        <div class="header-left">
            <img src="../admin/assets/logo.png" alt="Logo">
            <div class="dropdown">
                <button onclick="toggleDropdown()">Filter Quizzes</button>
                <div class="dropdown-menu">
                    <a href="#" onclick="filterQuizzes('Division')">Division</a>
                    <a href="#" onclick="filterQuizzes('Multiply')">Multiplication</a>
                    <a href="#" onclick="filterQuizzes('Quadratic')">Quadratic Equation</a>
                    <a href="#" onclick="filterQuizzes('Linear')">Linear Equation</a>
                    <a href="#" onclick="filterQuizzes('All')">All</a>
                </div>
            </div>
            <input type="text" id="search-bar" placeholder="Search quizzes..." onkeyup="searchQuizzes()" />
        </div>
        <div class="header-right">
            <a href="adminhomepage.php" class="back-btn">Back to Dashboard</a>
        </div>
    </header>

    <main>
        <h2>Quizzes</h2>
        <div id="quiz-container" class="quiz-container">
            <?php foreach ($allQuizzes as $quiz): ?>
                <div class="quiz-card" data-category="<?php echo htmlspecialchars($quiz['category']); ?>">
                    <div class="main-content">
                        <strong><?php echo htmlspecialchars($quiz['title']); ?></strong><br>
                        <span><?php echo htmlspecialchars($quiz['category']); ?></span>
                    </div>
                    <div class="parts">
                        <div class="part test-run"
                            onclick="location.href='admin_testrun.php?quiz_id=<?php echo $quiz['quiz_id']; ?>'">
                            <img src="assets/test.png" alt="Test Run">
                        </div>
                        <div class="part edit"
                            onclick="location.href='admin_edit_quiz.php?quiz_id=<?php echo $quiz['quiz_id']; ?>'">
                            <img src="assets/edit.png" alt="Edit Quiz">
                        </div>
                        <div class="part delete" onclick="confirmDelete('<?php echo $quiz['quiz_id']; ?>')">
                            <img src="assets/delete.png" alt="Delete Quiz">
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script>
        function searchQuizzes() {
            const input = document.getElementById('search-bar');
            const filter = input.value.toLowerCase();
            const quizCards = document.querySelectorAll('.quiz-card');

            quizCards.forEach(card => {
                const title = card.querySelector('.main-content strong').textContent.toLowerCase();
                if (title.includes(filter)) {
                    card.style.display = 'block'; // Show the card if it matches
                } else {
                    card.style.display = 'none'; // Hide the card if it doesn't match
                }
            });
        }
        function toggleDropdown() {
            const menu = document.querySelector('.dropdown-menu');
            menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        }

        function filterQuizzes(category) {
            const quizCards = document.querySelectorAll('.quiz-card');
            quizCards.forEach(card => {
                const quizCategory = card.dataset.category;
                card.style.display = category === 'All' || quizCategory === category ? 'block' : 'none';
            });
        }

        function confirmDelete(quizId) {
            const confirmation = confirm('Are you sure you want to delete this quiz? This action cannot be undone.');
            if (confirmation) {
                fetch('delete_quiz.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `quiz_id=${encodeURIComponent(quizId)}`
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Quiz deleted successfully!');
                            const quizCard = document.querySelector(`.quiz-card[data-quiz-id="${quizId}"]`);

                            if (quizCard) {
                                // Add fade-out effect
                                quizCard.style.transition = 'opacity 0.5s ease';
                                quizCard.style.opacity = '0';

                                // Wait for animation to complete, then remove the card
                                setTimeout(() => {
                                    quizCard.remove();
                                }, 500); // 500ms matches the CSS animation time
                            }
                        } else {
                            alert('Failed to delete the quiz: ' + data.message);
                        }
                    })
                    .catch(error => {
                        alert('An error occurred while deleting the quiz.');
                        console.error('Error:', error);
                    });
            }
        }


    </script>


</body>

</html>