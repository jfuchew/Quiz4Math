<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Allowed tables and their primary key mappings
$allowed_tables = [
    'shop' => 'item_id',
    'title' => 'title_id',
    'achievement' => 'achievement_id'
];

$allowed_columns = ['display'];

if (isset($_POST['item_id'], $_POST['new_value'], $_POST['table'], $_POST['column'])) {
    $item_id = $_POST['item_id']; 
    $new_value = $_POST['new_value'];
    $table = $_POST['table'];
    $column = $_POST['column'];

    if (!array_key_exists($table, $allowed_tables) || !in_array($column, $allowed_columns)) {
        echo json_encode(['success' => false, 'message' => 'Invalid table or column']);
        exit;
    }

    $primary_key = $allowed_tables[$table];

    if (!empty($item_id)) {
        $sql = "UPDATE `$table` SET `$column` = ? WHERE `$primary_key` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $new_value, $item_id);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Update successful']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update']);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid item_id']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Required parameters missing']);
}

$conn->close();
?>
