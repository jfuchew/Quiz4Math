<?php
session_start(); // Start session

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../stuint/login.php"); // Redirect to admin login page if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo "Invalid request method.";
    exit();
}

// Check if quiz_id and questions are present
if (!isset($_POST['quiz_id']) || !isset($_POST['questions'])) {
    echo "Invalid request. Required data is missing.";
    exit();
}

$quiz_id = $_POST['quiz_id'];
$questions = $_POST['questions'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Flag to track if updates were successful
$allUpdatesSuccessful = true;

// Prepare the SQL statement to update each question
$sql = "UPDATE question 
        SET question = ?, 
            option_a = ?, 
            option_b = ?, 
            option_c = ?, 
            option_d = ?, 
            correct_answer = ? 
        WHERE question_id = ? AND quiz_id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo "Error preparing SQL statement: " . $conn->error;
    exit();
}

// Loop through each question and update it
foreach ($questions as $question) {
    $question_id = $question['question_id'];
    $question_text = $question['question'];
    $option_a = $question['option_a'];
    $option_b = $question['option_b'];
    $option_c = $question['option_c'];
    $option_d = $question['option_d'];
    $correct_answer = $question['correct_answer'];

    // Bind and execute the statement for each question
    $stmt->bind_param(
        'ssssssss', 
        $question_text, 
        $option_a, 
        $option_b, 
        $option_c, 
        $option_d, 
        $correct_answer, 
        $question_id, 
        $quiz_id
    );

    if (!$stmt->execute()) {
        $allUpdatesSuccessful = false;
        echo "Error updating question with ID $question_id: " . $stmt->error;
    }
}

$stmt->close();
$conn->close();

if ($allUpdatesSuccessful) {
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Quiz Update</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                background-color: #f4f4f9;
                color: #333;
                margin: 0;
            }
            .message {
                text-align: center;
                background-color: #fff;
                padding: 20px 40px;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            .message h1 {
                font-size: 24px;
                margin-bottom: 10px;
            }
            .message p {
                font-size: 18px;
                margin-bottom: 20px;
            }
            .message button {
                padding: 10px 20px;
                font-size: 16px;
                background-color: #28a745;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .message button:hover {
                background-color: #218838;
            }
        </style>
    </head>
    <body>
        <div class="message">
            <h1>Quiz Updated Successfully!</h1>
            <p>All questions for this quiz have been updated.</p>
            <button onclick="window.location.href=\'admin_quiz_browse.php\'">Back</button>
        </div>
    </body>
    </html>
    ';
} else {
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Quiz Update</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                background-color: #f4f4f9;
                color: #333;
                margin: 0;
            }
            .message {
                text-align: center;
                background-color: #fff;
                padding: 20px 40px;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            .message h1 {
                font-size: 24px;
                margin-bottom: 10px;
            }
            .message p {
                font-size: 18px;
                margin-bottom: 20px;
            }
            .message button {
                padding: 10px 20px;
                font-size: 16px;
                background-color: #dc3545;
                color: white;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            .message button:hover {
                background-color: #c82333;
            }
        </style>
    </head>
    <body>
        <div class="message">
            <h1>Quiz Update Failed</h1>
            <p>Some questions could not be updated. Please try again.</p>
            <button onclick="window.history.back()">Go Back</button>
        </div>
    </body>
    </html>
    ';
}
