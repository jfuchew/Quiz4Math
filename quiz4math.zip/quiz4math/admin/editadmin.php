<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$adminId = "";
$name = "";
$email = "";
$password = "";
$message = "";

// Check if 'id' is present in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $adminId = $_GET['id'];

    // Sanitize and retrieve current admin data
    $adminId = $conn->real_escape_string($adminId);
    $query = "SELECT * FROM admin WHERE admin_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $adminId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $adminData = $result->fetch_assoc();
        $name = $adminData['name'];
        $email = $adminData['email'];
        $password = $adminData['password'];
    } else {
        header("Location: adminhomepage.php?message=Error: Admin not found.");
        exit;
    }
    $stmt->close();
}

// Handle form submission for editing admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $adminId = trim($_POST['admin_id']);

    // Validate input fields
    if (empty($name) || empty($email) || empty($password)) {
        $message = "All fields are required.";
    } else {
        // Update the admin data in the database
        $updateQuery = "UPDATE admin SET name = ?, email = ?, password = ? WHERE admin_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ssss", $name, $email, $password, $adminId);

        if ($stmt->execute()) {
            header("Location: adminhomepage.php?message=Admin with ID $adminId updated successfully.");
            exit;
        } else {
            $message = "Error: Unable to update admin.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Admin</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      background-color: #f4f4f9;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .form-container {
      background-color: #ffffff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
    }

    .form-container h1 {
      margin-bottom: 20px;
      text-align: center;
      color: #34495e;
    }

    .form-container label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-container input[type="text"], 
    .form-container input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-container button {
      background-color: #2ecc71;
      color: white;
      border: none;
      padding: 10px 15px;
      width: 100%;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    .form-container button:hover {
      background-color: #27ae60;
    }

    .form-container .back-button {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 10px 15px;
      width: 100%;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
    }

    .form-container .back-button:hover {
      background-color: #2980b9;
    }

    .message {
      margin-top: 20px;
      text-align: center;
      font-size: 14px;
      color: #e74c3c;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h1>Edit Admin Account</h1>
    <form method="POST" action="">
      <input type="hidden" name="admin_id" value="<?= htmlspecialchars($adminId); ?>">

      <label for="name">Name:</label>
      <input type="text" id="name" name="name" value="<?= htmlspecialchars($name); ?>" required>

      <label for="email">Email:</label>
      <input type="text" id="email" name="email" value="<?= htmlspecialchars($email); ?>" required>

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" value="<?= htmlspecialchars($password); ?>" required>

      <button type="submit">Update Account</button>
    </form>

    <!-- Back Button -->
    <button class="back-button" onclick="window.location.href='adminhomepage.php'">Back to Admin Dashboard</button>

    <?php if (!empty($message)): ?>
      <p class="message"><?= htmlspecialchars($message); ?></p>
    <?php endif; ?>
  </div>
</body>
</html>
