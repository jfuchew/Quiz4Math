<div class="sidebar" id="sidebar">
  <h2 id="sidebar-header">
    <a href="adminhomepage.php">
      <img src="assets/logo.png" alt="Admin Dashboard" id="sidebar-logo">
    </a>
  </h2>

  <div class="nav-links" id="nav-links">
    <a href="adminhomepage.php"
      class="<?php echo basename($_SERVER['PHP_SELF']) == 'adminhomepage.php' ? 'active' : ''; ?>">Home</a>
    <a href="admin_quiz_browse.php" class=""<?php echo basename($_SERVER['PHP_SELF']) == 'admin_quiz_browse.php' ? 'active' : ''; ?>">Browse Quiz</a>
    <a href="adminsetupquiz.php" class=""<?php echo basename($_SERVER['PHP_SELF']) == 'adminsetupquiz.php' ? 'active' : ''; ?>">Create Quiz</a>
    <a href="studentmanagement.php"
      class="<?php echo basename($_SERVER['PHP_SELF']) == 'studentmanagement.php' ? 'active' : ''; ?>">Manage
      Students</a>
    <a href="instructormanagement.php"
      class="<?php echo basename($_SERVER['PHP_SELF']) == 'instructormanagement.php' ? 'active' : ''; ?>">Manage
      Instructors</a>
    <a href="shopadmin.php"
      class="<?php echo basename($_SERVER['PHP_SELF']) == 'shopadmin.php' ? 'active' : ''; ?>">Manage Shop</a>
  </div>

  <button class="logout-button" id="logout-button" onclick="confirmLogout()">Logout</button>
</div>

<button class="toggle-button" id="toggle-button" onclick="toggleSidebar()">☰</button>

<style>
  .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100%;
    background-color: #34495e;
    color: #ecf0f1;
    padding: 20px;
    z-index: 1000;
    display: flex;
    flex-direction: column;
    transition: transform 0.3s ease;
    transform: translateX(0);
  }

  .sidebar.active {
    transform: translateX(-100%);
  }

  @media (max-width: 768px) {
    .sidebar {
      transform: translateX(-100%);
    }

    .sidebar.active {
      transform: translateX(0);
    }
  }


  #sidebar-header {
    text-align: center;
    margin-bottom: 20px;
  }

  #sidebar-logo {
    width: 100px;
    height: auto;
  }

  .nav-links a {
    display: block;
    color: #ecf0f1;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 4px;
    margin-bottom: 10px;
    transition: background-color 0.3s ease;
  }

  .nav-links a:hover {
    background-color: #2c3e50;
  }

  .nav-links a.active {
    background-color: #2c3e50;
    font-weight: bold;
  }

  .logout-button {
    background-color: #e74c3c;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
  }

  .logout-button:hover {
    background-color: #c0392b;
  }

  .toggle-button {
    position: fixed;
    top: 15px;
    left: 15px;
    background-color: #3498db;
    color: white;
    font-size: 20px;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    z-index: 1100;
    display: none;
  }

  .toggle-button:hover {
    background-color: #2980b9;
  }


  @media (max-width: 768px) {
    .toggle-button {
      display: block;
      width: 40px;
      height: 40px;
      font-size: 18px;
    }

    .sidebar {
      left: -250px;
    }

    .sidebar.active {
      left: 0;
    }
  }
</style>

<script>
  function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
  }

  function confirmLogout() {
    const userConfirmed = confirm("Are you sure you want to log out?");
    if (userConfirmed) {
      window.location.href = '../stuint/login.php';
    }
  }
</script>