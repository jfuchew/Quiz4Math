<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../stuint/login.php');
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the student ID
$student_id = isset($_GET['id']) ? $_GET['id'] : '';

if (!$student_id) {
    die("Invalid request. Student ID is missing.");
}

// Initialize variables for the form
$name = $email = $password = $level = $balance = "";

// If the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $level = $_POST['level'];
    $balance = $_POST['balance'];


    $updateQuery = "UPDATE student SET name = ?, email = ?, password = ?, level = ?, balance = ? WHERE student_id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("sssdis", $name, $email, $hashed_password, $level, $balance, $student_id);

    if ($stmt->execute()) {
        header("Location: studentmanagement.php?message=Successfully updated student account.");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Fetch current data for the student
    $query = "SELECT * FROM student WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $email = $row['email'];
        $password = ""; // Do not prefill the hashed password
        $level = $row['level'];
        $balance = $row['balance'];
    } else {
        die("Student not found.");
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student Account</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
        }

        .content-center {
            max-width: 600px;
            margin: 50px auto;
            background: #ffffff;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn, .back-button {
            background-color: #2ecc71;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
            width: 100%;
            text-decoration: none; /* Removes underline */
            display: block;
            box-sizing: border-box;
        }

        .btn:hover {
            background-color: #27ae60;
        }

        .back-button {
            background-color: #3498db;
            margin-top: 10px;
        }

        .back-button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="content-center">
        <h1>Edit Student Account</h1>
        <form method="POST">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

            <label for="password">Password:</label>
            <input type="text" id="password" name="password" placeholder="Enter new password" required>

            <label for="level">Level:</label>
            <input type="number" id="level" name="level" value="<?= htmlspecialchars($level) ?>" required>

            <label for="balance">Balance:</label>
            <input type="number" id="balance" name="balance" value="<?= htmlspecialchars($balance) ?>" required>

            <button type="submit" class="btn">Update</button>
            <a href="studentmanagement.php" class="back-button">Back</a>
        </form>
    </div>
</body>
</html>
