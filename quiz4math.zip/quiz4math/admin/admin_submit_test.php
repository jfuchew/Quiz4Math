<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

$admin_id = $_SESSION['admin_id'];
$quiz_id = isset($_POST['quiz_id']) ? $_POST['quiz_id'] : null;
$test_id = isset($_POST['test_id']) ? $_POST['test_id'] : null;
$start_time = isset($_POST['start_time']) ? $_POST['start_time'] : null;
$end_time = isset($_POST['end_time']) ? $_POST['end_time'] : null;
$answers = isset($_POST['answer']) ? $_POST['answer'] : [];

// Check for required inputs
if (!$quiz_id || !$test_id || !$start_time || !$end_time) {
    echo "<script>alert('Required data is missing.'); window.location.href = 'admin_quiz_browse.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Calculate score
$correctAnswers = 0;
$totalQuestions = count($answers);

// If no answers were submitted, set totalQuestions to 0 to avoid division issues
if ($totalQuestions > 0) {
    foreach ($answers as $question_id => $answer) {
        $sql = "SELECT correct_answer FROM question WHERE question_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $question_id);
        $stmt->execute();
        $stmt->bind_result($correct_answer);
        $stmt->fetch();
        $stmt->close();

        if ($answer == $correct_answer) {
            $correctAnswers++;
        }
    }
}

// Save test attempt with admin_id instead of instructor_id
$sql = "INSERT INTO testattempt (test_id, admin_id, start_time, end_time, final_score, quiz_id) 
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ssssds', $test_id, $admin_id, $start_time, $end_time, $correctAnswers, $quiz_id);
$stmt->execute();
$stmt->close();

$conn->close();

// Redirect to the results page
header("Location: admin_testresult.php?score=$correctAnswers&total=$totalQuestions&quiz_id=$quiz_id");
exit;
?>
