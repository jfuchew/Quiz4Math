<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

$score = isset($_GET['score']) ? intval($_GET['score']) : 0;
$total = isset($_GET['total']) ? intval($_GET['total']) : 0;
$quiz_id = isset($_GET['quiz_id']) ? htmlspecialchars($_GET['quiz_id']) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f3f3f3;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007BFF;
            padding: 20px;
            font-size: 24px;
            color: white;
        }
        .results {
            margin-top: 50px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            display: inline-block;
            text-align: center;
        }
        .score {
            font-size: 32px;
            color: #28a745;
            font-weight: bold;
        }
        .message {
            font-size: 20px;
            color: #555;
            margin-top: 10px;
        }
        .buttons {
            margin-top: 30px;
        }
        .buttons button {
            padding: 10px 20px;
            font-size: 16px;
            margin: 5px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
            transition: 0.3s;
        }
        .buttons button:hover {
            opacity: 0.9;
        }
        .back {
            background-color: #007BFF;
            color: white;
        }
        .retry {
            background-color: #28a745;
            color: white;
        }
    </style>
</head>
<body>
    <header>Quiz Results</header>
    <div class="results">
        <p class="score">You scored <?php echo $score; ?> out of <?php echo $total; ?></p>
        <p class="message">
            <?php 
                if ($score == $total) {
                    echo "Excellent work! You got all questions right.";
                } elseif ($score > ($total / 2)) {
                    echo "Good job! You passed the quiz.";
                } else {
                    echo "Keep trying! You can do better.";
                }
            ?>
        </p>
    </div>
    <div class="buttons">
        <!-- Back to Dashboard -->
        <button class="back" onclick="window.location.href='admin_quiz_browse.php';">Back</button>

        <!-- Try Again -->
        <button class="retry" onclick="window.location.href='admin_testrun.php?quiz_id=<?php echo $quiz_id; ?>';">Try Again</button>
    </div>
</body>
</html>
