<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Pagination for student table
$recordsPerPage = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $recordsPerPage;

// Search functionality
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : "";

// Query to fetch student accounts with search and LIMIT
$studentQuery = "SELECT * 
                 FROM student 
                 WHERE email LIKE '%$search%' 
                 LIMIT $recordsPerPage OFFSET $offset";
$studentResult = $conn->query($studentQuery);

// Query to count total student records for pagination
$totalStudentQuery = "SELECT COUNT(*) AS total FROM student WHERE email LIKE '%$search%'";
$totalStudentResult = $conn->query($totalStudentQuery);
$totalStudents = $totalStudentResult->fetch_assoc()['total'] ?? 0;

// Calculate total pages
$totalPages = ceil($totalStudents / $recordsPerPage);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Management</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f9;
      margin: 0;
    }

    .dashboard-container {
      display: flex;
    }

    .main-content {
      padding: 20px;
      background-color: #ecf0f1;
      min-height: 100vh;
      width: 100%;
    }

    .content-center {
      max-width: 1200px;
      margin: 0 auto;
    }

    /* Search bar styling */
    .search-bar {
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 10px;
    }

    .search-bar input[type="text"] {
      flex-grow: 1;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }

    .search-bar button {
      padding: 10px 20px;
      font-size: 16px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .search-bar button:hover {
      background-color: #2980b9;
    }

    /* Table styling */
    .table-container {
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ddd;
      border-radius: 4px;
      background-color: #fff;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 16px;
    }

    table th,
    table td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: center;
    }

    table thead tr {
      background-color: #34495e;
      color: #ffffff;
    }

    table tbody tr:nth-child(even) {
      background-color: #f4f4f9;
    }

    button.delete-selected {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 10px 15px;
      margin-top: 10px;
      cursor: pointer;
      border-radius: 4px;
    }

    button.delete-selected:hover {
      background-color: #c0392b;
    }

    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }

    .pagination a {
      color: #3498db;
      padding: 10px 15px;
      text-decoration: none;
      border: 1px solid #ddd;
      border-radius: 4px;
      margin: 0 5px;
    }

    .pagination a:hover {
      background-color: #f1f1f1;
    }

    .pagination a.disabled {
      color: #aaa;
      pointer-events: none;
      cursor: not-allowed;
    }

    .action-buttons {
      display: flex;
      justify-content: space-evenly;
    }

    button.edit-account {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 8px 15px;
      cursor: pointer;
      border-radius: 4px;
      font-size: 14px;
    }

    button.edit-account:hover {
      background-color: #2980b9;
    }

    @media (max-width: 768px) {
      .content-center {
        padding: 0 10px;
      }

      .search-bar {
        flex-direction: column;
      }

      .search-bar input[type="text"] {
        width: 100%;
      }

      .search-bar button {
        width: 100%;
      }

      .table-container {
        max-height: 300px;
      }

      table {
        display: block;
        overflow-x: auto;
      }

      .dashboard-container {
        flex-direction: column;
      }
    }
  </style>
</head>

<body>

  <div class="dashboard-container">
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
      <div class="content-center">
        <h1>Student Management</h1>

        <!-- Search Bar -->
        <div class="search-bar">
          <form method="GET" action="">
            <input type="text" name="search" placeholder="Search by email..." value="<?= htmlspecialchars($search); ?>">
            <button type="submit">Search</button>
          </form>
        </div>

        <h2>Student Accounts</h2>
        <p>Showing <?= $offset + 1; ?> to <?= min($offset + $recordsPerPage, $totalStudents); ?> of
          <?= $totalStudents; ?> student accounts</p>

        <form method="POST" action="delete_selected_students.php">
          <!-- Scrollable container for the table -->
          <div class="table-container">
            <table>
              <thead>
                <tr>
                  <th><input type="checkbox" id="selectAll" onclick="toggleSelectAll(this)"></th>
                  <th>Student ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Level</th>
                  <th>Balance</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php
                if ($studentResult && $studentResult->num_rows > 0) {
                  while ($row = $studentResult->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td><input type='checkbox' name='selected_ids[]' value='" . htmlspecialchars($row['student_id']) . "'></td>";
                    echo "<td>" . htmlspecialchars($row['student_id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['level']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['balance']) . "</td>";
                    echo "<td class='action-buttons'>
                              <button type='button' class='edit-account' onclick=\"window.location.href='editstudent.php?id=" . htmlspecialchars($row['student_id']) . "'\">Edit</button>
                            </td>";
                    echo "</tr>";
                  }
                } else {
                  echo "<tr><td colspan='7'>No student accounts found</td></tr>";
                }
                ?>
              </tbody>
            </table>
          </div>

          <button type="submit" class="delete-selected">Delete Selected</button>
        </form>

        <!-- Pagination Controls -->
        <div class="pagination">
          <a href="?page=<?= max(1, $page - 1) ?>&search=<?= htmlspecialchars($search); ?>" class="<?= $page <= 1 ? 'disabled' : '' ?>">Previous</a>
          <a href="?page=<?= min($totalPages, $page + 1) ?>&search=<?= htmlspecialchars($search); ?>"
            class="<?= $page >= $totalPages ? 'disabled' : '' ?>">Next</a>
        </div>

      </div>
    </div>
  </div>

  <script>
    function toggleSelectAll(checkbox) {
      const checkboxes = document.querySelectorAll("input[type='checkbox'][name='selected_ids[]']");
      checkboxes.forEach(cb => cb.checked = checkbox.checked);
    }

    function confirmDelete(studentId) {
      if (confirm('Are you sure you want to delete this student?')) {
        window.location.href = `delete.php?id=${studentId}`;
      }
    }
  </script>

</body>

</html>
