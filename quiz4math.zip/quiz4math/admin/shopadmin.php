<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your database password
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch items from the shop table
$sql = "SELECT * FROM shop";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Shop</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
        }

        .dashboard-container {
            display: flex;
            flex-wrap: wrap;
        }

        .main-content {
            padding: 20px;
            background-color: #ecf0f1;
            min-height: 100vh;
            width: 100%;
        }

        .content-center {
            max-width: 1200px;
            margin: 0 auto;
        }

        .shop-section {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            background-color: #bdc3c7;
            padding: 20px;
            justify-content: center;
        }

        .shop-item {
            background-color: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            width: calc(33.33% - 20px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease-in-out;
        }

        .shop-item:hover {
            transform: scale(1.05);
        }

        .shop-item h3 {
            margin: 10px 0;
            font-size: 18px;
        }

        .shop-item p {
            margin: 5px 0;
            font-size: 14px;
            color: #7f8c8d;
        }

        .shop-item button {
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            color: #ffffff;
            width: 100%; /* Full width on mobile */
            margin-top: 10px;
        }

        .shop-item .listed {
            background-color: #27ae60; /* Green for Listed */
        }

        .shop-item .unlisted {
            background-color: #c0392b; /* Red for Unlisted */
        }

        @media (max-width: 768px) {
            .content-center {
                padding: 10px;
            }

            .shop-section {
                padding: 10px;
            }

            .shop-item {
                width: calc(50% - 20px); /* Two items per row on tablets */
            }

            .shop-item button {
                font-size: 14px;
                padding: 8px 12px;
            }

            .shop-item p {
                font-size: 12px;
            }

            .shop-item h3 {
                font-size: 16px;
            }
        }

        @media (max-width: 480px) {
            .shop-item {
                width: 100%; /* Full width on mobile */
            }

            .shop-item h3 {
                font-size: 16px;
            }

            .shop-item p {
                font-size: 12px;
            }

            .shop-item button {
                font-size: 14px;
                padding: 12px 15px;
            }
        }
    </style>
</head>

<body>

    <div class="dashboard-container">
        <?php include 'sidebar.php'; ?>

        <div class="main-content">
            <div class="content-center">

                <h1>Manage Shop</h1>

                <div class="shop-section">
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $isListed = $row['display'] ? 'listed' : 'unlisted';
                            $buttonText = $row['display'] ? 'Unlist' : 'List';
                            
                            echo '<div class="shop-item">';
                            echo '<h3>' . htmlspecialchars($row['title']) . '</h3>';
                            echo '<p>' . htmlspecialchars($row['description']) . '</p>';
                            echo '<p>Price: $' . htmlspecialchars($row['price']) . '</p>';
                            echo '<button 
                                class="toggle-display ' . $isListed . '" 
                                onclick="toggleItem(\'' . htmlspecialchars($row['item_id']) . '\', this, \'shop\', \'display\')">
                                ' . $buttonText . '
                              </button>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p>No items available in the shop.</p>';
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>

    <script>
        function toggleItem(itemId, button, table, column) {
            const isCurrentlyListed = button.classList.contains('listed');
            const newValue = isCurrentlyListed ? 0 : 1;

            fetch('update_display.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `item_id=${encodeURIComponent(itemId)}&new_value=${newValue}&table=${encodeURIComponent(table)}&column=${encodeURIComponent(column)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    button.classList.toggle('listed');
                    button.classList.toggle('unlisted');
                    button.textContent = newValue ? 'Unlist' : 'List';
                } else {
                    alert(data.message);
                }
            })
            .catch(err => console.error('Error:', err));
        }
    </script>

</body>

</html>
