<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'selected_ids' is set and not empty
if (isset($_POST['selected_ids']) && !empty($_POST['selected_ids'])) {
    // Correct the variable name from $studentIds to $instructorIds
    $instructorIds = $_POST['selected_ids'];

    // Sanitize and prepare the instructor IDs
    $placeholders = implode(',', array_fill(0, count($instructorIds), '?'));
    $deleteQuery = "DELETE FROM instructor WHERE instructor_id IN ($placeholders)";
    $stmt = $conn->prepare($deleteQuery);

    if ($stmt === false) {
        header("Location: instructormanagement.php?message=Error: Unable to prepare the delete statement.");
        exit;
    }

    // Dynamically bind the parameters
    $types = str_repeat('s', count($instructorIds)); // 's' for each instructor_id (all are strings)
    $stmt->bind_param($types, ...$instructorIds);

    // Execute and check if successful
    if ($stmt->execute()) {
        // Redirect back to instructor management with success message
        $count = count($instructorIds);
        header("Location: instructormanagement.php?message=Successfully deleted $count instructor(s).");
        exit;
    } else {
        // Redirect back to instructor management with error message
        header("Location: instructormanagement.php?message=Error: Unable to delete selected instructors.");
        exit;
    }

    $stmt->close();
} else {
    // Redirect back to instructor management if no instructors are selected
    header("Location: instructormanagement.php?message=Error: No instructor selected for deletion.");
    exit;
}

$conn->close();
?>
