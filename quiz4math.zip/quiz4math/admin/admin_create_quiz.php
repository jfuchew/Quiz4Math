<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
session_start();
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location.href = '../stuint/login.php';</script>";
    exit;
}

$quiz_id = $_GET['quiz_id'] ?? null;

if (!$quiz_id) {
    echo "<script>alert('No quiz selected.'); window.location.href = 'adminhomepage.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch quiz details
$sql = "SELECT title, question FROM quiz WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $quiz_id);
$stmt->execute();
$result = $stmt->get_result();
$quiz = $result->fetch_assoc();

if (!$quiz) {
    echo "<script>alert('Quiz not found.'); window.location.href = 'adminhomepage.php';</script>";
    exit;
}

$title = $quiz['title'];
$max_questions = $quiz['question'];
$stmt->close();

/**
 * Generates a unique question_id that does not exist in the database
 * @param mysqli $conn The MySQLi connection
 * @return string The unique question_id
 */
function generateUniqueQuestionId($conn) {
    while (true) {
        $randomId = 'ques_' . rand(10000, 99999); // Generate a random 5-digit number
        $checkQuery = "SELECT question_id FROM question WHERE question_id = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param('s', $randomId);
        $checkStmt->execute();
        $checkStmt->store_result();
        if ($checkStmt->num_rows === 0) { // If no rows returned, ID is unique
            $checkStmt->close();
            return $randomId;
        }
        $checkStmt->close();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process each question
    foreach ($_POST['questions'] as $index => $question_text) {
        $question_id = generateUniqueQuestionId($conn); 
        $option_a = $_POST['options'][$index]['A'];
        $option_b = $_POST['options'][$index]['B'];
        $option_c = $_POST['options'][$index]['C'];
        $option_d = $_POST['options'][$index]['D'];
        $correct_answer_value = $_POST['correct_answers'][$index]; // Get the actual option value for the correct answer

        // Insert or update the question into the database
        $sql = "REPLACE INTO question (question_id, quiz_id, question, option_a, option_b, option_c, option_d, correct_answer)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo "<script>alert('SQL Error: " . $conn->error . "');</script>";
            continue;
        }

        $stmt->bind_param('ssssssss', $question_id, $quiz_id, $question_text, $option_a, $option_b, $option_c, $option_d, $correct_answer_value);

        if (!$stmt->execute()) {
            echo "<script>alert('Failed to save question " . ($index + 1) . ": " . $stmt->error . "');</script>";
        }

        $stmt->close();
    }

    echo "<script>alert('Quiz questions saved successfully!'); window.location.href = 'adminhomepage.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz - <?php echo htmlspecialchars($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
        }
        .question-block {
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
            margin-bottom: 20px;
        }
        .question-block textarea,
        .question-block input,
        .question-block select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .submit-btn {
            display: block;
            width: 100%;
            padding: 15px;
            background-color: #28a745;
            color: white;
            font-size: 18px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Quiz: <?php echo htmlspecialchars($title); ?></h1>
        <form method="POST" action="">
            <?php for ($i = 0; $i < $max_questions; $i++): ?>
                <div class="question-block">
                    <label>Question <?php echo $i + 1; ?>:</label>
                    <textarea name="questions[<?php echo $i; ?>]" required></textarea>

                    <label>Option A</label>
                    <input type="text" name="options[<?php echo $i; ?>][A]" required oninput="updateCorrectOptions(<?php echo $i; ?>)">
                    
                    <label>Option B</label>
                    <input type="text" name="options[<?php echo $i; ?>][B]" required oninput="updateCorrectOptions(<?php echo $i; ?>)">
                    
                    <label>Option C</label>
                    <input type="text" name="options[<?php echo $i; ?>][C]" required oninput="updateCorrectOptions(<?php echo $i; ?>)">
                    
                    <label>Option D</label>
                    <input type="text" name="options[<?php echo $i; ?>][D]" required oninput="updateCorrectOptions(<?php echo $i; ?>)">

                    <label>Correct Answer</label>
                    <select name="correct_answers[<?php echo $i; ?>]" id="correct-answer-<?php echo $i; ?>" required>
                        <option value="">Select Correct Answer</option>
                    </select>
                </div>
            <?php endfor; ?>
            <button type="submit" class="submit-btn">Save Questions</button>
        </form>
    </div>

    <script>
        function updateCorrectOptions(index) {
            const optionA = document.querySelector(`[name="options[${index}][A]"]`).value;
            const optionB = document.querySelector(`[name="options[${index}][B]"]`).value;
            const optionC = document.querySelector(`[name="options[${index}][C]"]`).value;
            const optionD = document.querySelector(`[name="options[${index}][D]"]`).value;

            const correctAnswerSelect = document.getElementById(`correct-answer-${index}`);
            correctAnswerSelect.innerHTML = `
                <option value="${optionA}">${optionA}</option>
                <option value="${optionB}">${optionB}</option>
                <option value="${optionC}">${optionC}</option>
                <option value="${optionD}">${optionD}</option>
            `;
        }
    </script>
</body>
</html>
