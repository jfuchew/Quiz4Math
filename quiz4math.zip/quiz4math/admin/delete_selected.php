<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "quiz4math";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'selected_ids' is set and not empty
if (isset($_POST['selected_ids']) && !empty($_POST['selected_ids'])) {
    $adminIds = $_POST['selected_ids'];

    // Sanitize and prepare the admin IDs
    $placeholders = implode(',', array_fill(0, count($adminIds), '?'));
    $deleteQuery = "DELETE FROM admin WHERE admin_id IN ($placeholders)";
    $stmt = $conn->prepare($deleteQuery);

    // Dynamically bind the parameters
    $types = str_repeat('s', count($adminIds)); // 's' for each admin_id (all are strings)
    $stmt->bind_param($types, ...$adminIds);

    if ($stmt->execute()) {
        // Redirect back to adminhomepage with success message
        $count = count($adminIds);
        header("Location: adminhomepage.php?message=Successfully deleted $count admin(s).");
        exit;
    } else {
        // Redirect back to adminhomepage with error message
        header("Location: adminhomepage.php?message=Error: Unable to delete selected admins.");
        exit;
    }

    $stmt->close();
} else {
    // Redirect back to adminhomepage if no admins are selected
    header("Location: adminhomepage.php?message=Error: No admins selected for deletion.");
    exit;
}

$conn->close();
?>
