<?php
session_start(); // Start session

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../stuint/login.php"); // Redirect to admin login page if not logged in
    exit();
}

$quiz_id = $_GET['quiz_id'] ?? null;

if (!$quiz_id) {
    echo "<script>alert('No quiz selected.'); window.location.href = 'adminhomepage.php';</script>";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch quiz questions
$sql = "SELECT * FROM question WHERE quiz_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $quiz_id);
$stmt->execute();
$result = $stmt->get_result();
$questions = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Quiz Questions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        .question-block {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #007bff;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        textarea,
        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn-container {
            text-align: center;
        }

        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }

        .back-btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-right: 20px;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Edit Quiz Questions</h1>

    <form action="admin_save_edit_quiz.php" method="POST">
        <input type="hidden" name="quiz_id" value="<?php echo htmlspecialchars($quiz_id); ?>">

        <?php if (!empty($questions)): ?>
            <?php foreach ($questions as $index => $question): ?>
                <div class="question-block">
                    <input type="hidden" name="questions[<?php echo $index; ?>][question_id]" value="<?php echo htmlspecialchars($question['question_id']); ?>">

                    <label for="question-<?php echo $index; ?>">Question <?php echo $index + 1; ?></label>
                    <textarea name="questions[<?php echo $index; ?>][question]" rows="3"><?php echo htmlspecialchars($question['question']); ?></textarea>

                    <label>Option A</label>
                    <input type="text" name="questions[<?php echo $index; ?>][option_a]" value="<?php echo htmlspecialchars($question['option_a']); ?>" oninput="updateCorrectOptions(<?php echo $index; ?>)">

                    <label>Option B</label>
                    <input type="text" name="questions[<?php echo $index; ?>][option_b]" value="<?php echo htmlspecialchars($question['option_b']); ?>" oninput="updateCorrectOptions(<?php echo $index; ?>)">

                    <label>Option C</label>
                    <input type="text" name="questions[<?php echo $index; ?>][option_c]" value="<?php echo htmlspecialchars($question['option_c']); ?>" oninput="updateCorrectOptions(<?php echo $index; ?>)">

                    <label>Option D</label>
                    <input type="text" name="questions[<?php echo $index; ?>][option_d]" value="<?php echo htmlspecialchars($question['option_d']); ?>" oninput="updateCorrectOptions(<?php echo $index; ?>)">

                    <label>Correct Answer</label>
                    <select name="questions[<?php echo $index; ?>][correct_answer]" id="correct-answer-<?php echo $index; ?>">
                        <option value="<?php echo htmlspecialchars($question['option_a']); ?>" <?php if ($question['correct_answer'] == $question['option_a']) echo 'selected'; ?>><?php echo htmlspecialchars($question['option_a']); ?></option>
                        <option value="<?php echo htmlspecialchars($question['option_b']); ?>" <?php if ($question['correct_answer'] == $question['option_b']) echo 'selected'; ?>><?php echo htmlspecialchars($question['option_b']); ?></option>
                        <option value="<?php echo htmlspecialchars($question['option_c']); ?>" <?php if ($question['correct_answer'] == $question['option_c']) echo 'selected'; ?>><?php echo htmlspecialchars($question['option_c']); ?></option>
                        <option value="<?php echo htmlspecialchars($question['option_d']); ?>" <?php if ($question['correct_answer'] == $question['option_d']) echo 'selected'; ?>><?php echo htmlspecialchars($question['option_d']); ?></option>
                    </select>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No questions found for this quiz.</p>
        <?php endif; ?>

        <div class="btn-container">
            <button type="button" class="back-btn" onclick="location.href='admin_quiz_browse.php'">Back</button>
            <button type="submit">Save Changes</button>
        </div>
    </form>
</div>

<script>
    function updateCorrectOptions(index) {
        const optionA = document.querySelector(`[name="questions[${index}][option_a]"]`).value;
        const optionB = document.querySelector(`[name="questions[${index}][option_b]"]`).value;
        const optionC = document.querySelector(`[name="questions[${index}][option_c]"]`).value;
        const optionD = document.querySelector(`[name="questions[${index}][option_d]"]`).value;
        
        const correctAnswerSelect = document.getElementById(`correct-answer-${index}`);
        correctAnswerSelect.innerHTML = `
            <option value="${optionA}">${optionA}</option>
            <option value="${optionB}">${optionB}</option>
            <option value="${optionC}">${optionC}</option>
            <option value="${optionD}">${optionD}</option>
        `;
    }
</script>

</body>
</html>
