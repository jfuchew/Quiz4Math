<?php
session_start(); // Start session

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'You are not authorized to delete this quiz.']);
    exit();
}

// Check if the request is POST and if the quiz_id is set
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['quiz_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request. Quiz ID is missing.']);
    exit();
}

$quiz_id = $_POST['quiz_id'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'quiz4math');
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

try {
    // Start a transaction to ensure data integrity
    $conn->begin_transaction();

    // Delete related questions first (assuming foreign key constraint exists)
    $deleteQuestionsSql = "DELETE FROM question WHERE quiz_id = ?";
    $stmt = $conn->prepare($deleteQuestionsSql);
    if (!$stmt) {
        throw new Exception('SQL preparation error for questions: ' . $conn->error);
    }
    $stmt->bind_param('s', $quiz_id);
    if (!$stmt->execute()) {
        throw new Exception('Failed to delete related questions: ' . $stmt->error);
    }
    $stmt->close();

    // Delete the quiz
    $deleteQuizSql = "DELETE FROM quiz WHERE quiz_id = ?";
    $stmt = $conn->prepare($deleteQuizSql);
    if (!$stmt) {
        throw new Exception('SQL preparation error for quiz: ' . $conn->error);
    }
    $stmt->bind_param('s', $quiz_id);
    if (!$stmt->execute()) {
        throw new Exception('Failed to delete quiz: ' . $stmt->error);
    }

    $stmt->close();
    $conn->commit(); // Commit the transaction
    $conn->close();

    echo json_encode(['success' => true, 'message' => 'Quiz deleted successfully.']);
} catch (Exception $e) {
    $conn->rollback(); // Rollback the transaction on error
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
